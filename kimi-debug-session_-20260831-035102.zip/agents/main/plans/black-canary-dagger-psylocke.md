# SatQuery AI — Backend Implementation Plan

## Goal
Build a Python/FastAPI backend (SQLite + local storage) that replaces the frontend's
mock data pipeline with a real API. The frontend currently self-contains all "AI"
behavior via `src/data/mockResponses.ts`, `mockDatasets.ts`, and timed delays. This
backed provides those same capabilities over HTTP, including: dataset serving, image
ingestion (GeoTIFF metadata parsing), an agentic orchestration pipeline (with simulated
specialist models), analysis-history persistence, and JWT auth.

Scope: build the backend and a thin client (API layer) that the frontend can adopt.
No attempt to train real ML models — specialist models are *simulation* engines that
produce evidence-grounded responses matching the shapes the frontend already expects.

## Tech Stack (user-selected)
- **Language/Framework**: Python 3.11+ / FastAPI
- **Storage**: SQLite (via SQLAlchemy) + local disk image storage
- **Auth**: JWT (python-jose / PyJWT, passlib bcrypt)
- **Image processing**: rasterio (GeoTIFF metadata/bands), Pillow (thumbnails); graceful
  fallback if rasterio unavailable
- **Async**: async endpoints; orchestration runs as async tasks streaming progress
- **Frontend integration**: generated TypeScript client (+ Vite dev proxy `/api` → backend)

## Backend Directory Layout
```
backend/
  pyproject.toml            # deps & scripts (uv/pip optional)
  requirements.txt
  README.md                 # how to run, endpoints
  app/
    __init__.py
    main.py                 # FastAPI app, CORS, router mounting, startup
    config.py               # settings (env-driven): DB path, upload dir, JWT secret
    database.py             # SQLAlchemy engine/session, Base
    models.py               # ORM: User, Image, Dataset, Analysis, ChatMessage
    schemas.py              # Pydantic request/response schemas (mirror frontend types)
    security.py             # JWT create/verify, password hashing, current_user dep
    deps.py                 # FastAPI dependencies (db session, current user)
    routers/
      __init__.py
      auth.py               # POST /auth/register, /auth/login, /auth/me
      datasets.py           # GET /datasets, GET /datasets/{id}
      images.py             # POST /images/upload (multipart), GET /images/{id}
      analysis.py           # POST /analysis (run pipeline), GET /analysis/history
      models_registry.py    # GET /models (specialist registry)
    services/
      __init__.py
      orchestrator.py       # query→plan→select→execute→synthesize pipeline
      specialist.py         # simulated specialist models (VLM, CD, SAR, geo, cls, det)
      image_service.py      # GeoTIFF metadata parse, thumbnail generation, storage
      storage.py            # local disk storage helpers
    seed.py                 # seed SQLite with mock datasets & users on first run
  tests/
    test_auth.py
    test_analysis.py
    test_datasets.py
```

## API Contract (mirrors frontend types)
Base path `/api`. Auth via `Authorization: Bearer <jwt>`.

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/auth/register` | create user |
| POST | `/auth/login` | returns JWT + user |
| GET  | `/auth/me` | current user |
| GET  | `/datasets` | list datasets (with nested image) |
| GET  | `/datasets/{id}` | one dataset |
| POST | `/images/upload` | multipart image upload → parse GeoTIFF metadata, store, gen thumbnail, return `SatelliteImage` |
| GET  | `/images/{id}/file` | serve stored binary |
| GET  | `/images/{id}/thumbnail` | serve thumbnail |
| GET  | `/models` | specialist model registry (matching `mockSpecialistModels`) |
| POST | `/analysis` | run orchestration on given image(s)+query → returns ChatMessage + AnalysisResult + model trace |
| GET  | `/analysis/history` | saved analyses for current user |
| GET  | `/health` | health check |

Pydantic schemas mirror the frontend TS interfaces (`SatelliteImage`, `DatasetSample`,
`ChatMessage`, `AnalysisResult`, `EvidenceItem`, `ModelTraceStep`, `OrchestrationStep`),
serializing dates as ISO-8601 strings to match what the frontend already parses.

## Orchestration Pipeline (`services/orchestrator.py`)
Replicates the 5-step flow the frontend animates, but server-side, returning the live
step states and a synthesized answer:
1. **Query Understanding** — classify query into `landcover | change | multimodal |
   detection | general` using keyword heuristics.
2. **Task Planning** — derive required modalities and analysis steps from classification.
3. **Specialist Selection** — pick from the 6 registries based on task (mirrors
   `mockSpecialistModels`).
4. **Execution** — run the selected simulated specialists over the image(s). Each
   specialist inspects the image metadata/basic pixel stats and emits typed `EvidenceItem`s
   with confidence scores (deterministic but plausible: built-up %, NDVI, water, etc.).
5. **Evidence Synthesis** — combine evidence into a grounded `AnalysisResult` + `ChatMessage`
   with `modelsUsed`, `confidence`, `processingTime`, `modelTrace`.

Progress streaming: the endpoint returns the final result synchronously (frontend keeps its
existing timer UI), and we also offer an optional `ws://.../analysis/{id}` WebSocket that
emits step-progress ticks for future use. Primary contract is the REST response.

## Image Service
- Accept multipart uploads (`.tif/.tiff/.png/.jpg/.geotiff`).
- Use **rasterio** to read GeoTIFF metadata: dimensions, band list, CRS, geotransform →
  derive bbox/lat-lng and resolution; Pillow for thumbnail. If rasterio is not installed,
  fall back to Pillow (PNG/JPEG) + synthetic geospatial values so the app still runs.
- Store bytes on local disk under `DATA_DIR/uploads`; record row in SQLite.

## Auth & Seed
- JWT access tokens (HS256) with expiry; bcrypt password hashing.
- `seed.py` populates users, the 6 mock datasets, and a demo account (`demo@satquery.ai` /
  `demo1234`) so the app is usable immediately.

## Testing
- pytest + httpx/TestClient for: auth (register/login/me), datasets list, image upload,
  analysis pipeline shapes, history persistence.
- Frontend integration: add a `vite.config.ts` proxy (`/api` → `http://localhost:8000`) and
  an `src/lib/api.ts` client + `src/lib/types.ts` mapping. NOTE: wiring the frontend to the
  new API is a follow-up step — this plan focuses on backend + client scaffold; swapping the
  frontend's internal mock* usage for API calls will be done incrementally to avoid breaking
  the working UI.

## Run / Verify
- `cd backend && pip install -r requirements.txt`
- `uvicorn app.main:app --reload --port 8000`
- `pytest` to run backend tests
- `curl` smoke checks against `/api/health`, `/api/datasets`, `/api/analysis`

## Out of Scope
- Training/loading real ML models (specialists are simulated).
- Production hardening (rate limiting, refresh tokens, CSRF).
- Containerization (Dockerfile) will be a small add-on if requested.
